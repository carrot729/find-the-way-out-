//Your output is a string which contains only lowercase letters. In this subtask, it is "iwanttoescape". The password is "wstgbpojwryvrudfsvhe" for subtasks 2 to 6.


#include <iostream>
using namespace std;


int main(){
    cout<<"iwanttoescape";
}